# ProductAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**CreditCardProductAdd**](CreditCardProductAdd.md) |  | [optional] 
**ready_credit_product** | [**ReadyCreditProductAdd**](ReadyCreditProductAdd.md) |  | [optional] 
**unsecured_loan_product** | [**UnsecuredLoanProductAdd**](UnsecuredLoanProductAdd.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

