# MarketingConsent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**personal_data_opt_out_others_flag** | **bool** | Opt out from use of personal data to other person/organization in direct marketing | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

