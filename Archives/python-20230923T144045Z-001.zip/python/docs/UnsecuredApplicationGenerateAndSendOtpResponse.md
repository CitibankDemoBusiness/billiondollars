# UnsecuredApplicationGenerateAndSendOtpResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**masked_phone_number** | **str** | The Customers phone number having last four digits unmasked | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

