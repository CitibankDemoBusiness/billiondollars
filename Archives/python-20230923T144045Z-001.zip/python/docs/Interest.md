# Interest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_group** | **str** | A unique code that identifies the product group. This is prospect selected product | 
**campaign_id** | **str** | Campaign Id. The unique identifier for campaign. | [optional] 
**wave_id** | **str** | Wave Id corresponding to campaign. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

