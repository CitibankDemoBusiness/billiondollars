# UpdateApplicationProcessingPartnerMembershipValidationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**membership_information** | [**MembershipInformation**](MembershipInformation.md) |  | [optional] 
**sales_agent_details** | [**SalesAgentDetails**](SalesAgentDetails.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**consent_details** | [**list[ConsentDetails]**](ConsentDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

