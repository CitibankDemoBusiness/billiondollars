# ProductUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**CreditCardProductUpdate**](CreditCardProductUpdate.md) |  | [optional] 
**ready_credit_product** | [**ReadyCreditProductUpdate**](ReadyCreditProductUpdate.md) |  | [optional] 
**unsecured_loan_product** | [**UnsecuredLoanProductUpdate**](UnsecuredLoanProductUpdate.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

