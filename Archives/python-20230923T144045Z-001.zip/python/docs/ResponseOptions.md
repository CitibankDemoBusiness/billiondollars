# ResponseOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**option_sequence_number** | **int** | Option sequence number | [optional] 
**selected_flag** | **bool** | Identifer used to determine the if the option was selected on not. Default value is false. | [optional] 
**option_text** | **str** | Option text to be displayed to the end user. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

