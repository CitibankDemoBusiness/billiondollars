# SwaggerClient::Document

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document_format** | **String** | The format for the document. | [optional] 
**encode_type** | **String** | Image Encoding Type e.g. base16, base64 | [optional] 
**data_payload** | **String** | This field contains binary data for the statement. | [optional] 

