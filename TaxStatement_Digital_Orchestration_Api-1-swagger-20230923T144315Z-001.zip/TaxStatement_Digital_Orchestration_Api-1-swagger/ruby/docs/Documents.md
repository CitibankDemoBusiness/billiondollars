# SwaggerClient::Documents

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document_details** | [**Array&lt;DocumentDetails&gt;**](DocumentDetails.md) |  | [optional] 

