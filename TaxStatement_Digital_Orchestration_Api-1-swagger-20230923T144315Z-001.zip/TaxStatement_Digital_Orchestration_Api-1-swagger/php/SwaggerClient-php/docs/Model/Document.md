# Document

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document_format** | **string** | The format for the document. | [optional] 
**encode_type** | **string** | Image Encoding Type e.g. base16, base64 | [optional] 
**data_payload** | **string** | This field contains binary data for the statement. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

