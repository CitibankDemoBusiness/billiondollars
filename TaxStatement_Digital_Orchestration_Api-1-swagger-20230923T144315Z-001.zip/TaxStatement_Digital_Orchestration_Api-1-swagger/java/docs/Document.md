# Document

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**documentFormat** | **String** | The format for the document. |  [optional]
**encodeType** | **String** | Image Encoding Type e.g. base16, base64 |  [optional]
**dataPayload** | **String** | This field contains binary data for the statement. |  [optional]
