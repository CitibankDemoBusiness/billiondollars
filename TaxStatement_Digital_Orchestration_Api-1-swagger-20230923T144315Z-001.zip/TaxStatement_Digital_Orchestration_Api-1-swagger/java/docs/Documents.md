# Documents

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**documentDetails** | [**List&lt;DocumentDetails&gt;**](DocumentDetails.md) |  |  [optional]
