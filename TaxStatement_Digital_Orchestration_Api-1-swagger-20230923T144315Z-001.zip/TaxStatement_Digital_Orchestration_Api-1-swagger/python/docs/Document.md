# Document

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document_format** | **str** | The format for the document. | [optional] 
**encode_type** | **str** | Image Encoding Type e.g. base16, base64 | [optional] 
**data_payload** | **str** | This field contains binary data for the statement. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

