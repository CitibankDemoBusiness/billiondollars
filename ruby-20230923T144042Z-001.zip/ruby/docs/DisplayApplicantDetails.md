# SwaggerClient::DisplayApplicantDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**ECMName**](ECMName.md) |  | 
**address** | [**Array&lt;ECMAddress&gt;**](ECMAddress.md) |  | [optional] 

