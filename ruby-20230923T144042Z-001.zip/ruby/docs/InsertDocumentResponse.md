# SwaggerClient::InsertDocumentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**binary_data_size** | **String** | Binary stream size of the document. | 

