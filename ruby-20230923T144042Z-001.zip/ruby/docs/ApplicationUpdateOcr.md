# SwaggerClient::ApplicationUpdateOcr

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ocr_reference_number** | **String** | OCR (Optical Character Recognition) Reference number | [optional] 

