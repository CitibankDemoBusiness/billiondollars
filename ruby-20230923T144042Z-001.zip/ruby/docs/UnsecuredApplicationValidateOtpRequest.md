# SwaggerClient::UnsecuredApplicationValidateOtpRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**otp_token** | **String** | Encrypted OTP Token to be validated | 
**control_flow_id** | **String** | Control Flow Id | 

