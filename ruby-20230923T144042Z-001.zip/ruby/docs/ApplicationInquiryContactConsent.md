# SwaggerClient::ApplicationInquiryContactConsent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ok_to_call** | **BOOLEAN** | Applicant&#x27;s consent for receiving phone calls. Valid values: true and false | [optional] 
**ok_to_mail** | **BOOLEAN** | Applicant&#x27;s consent for receiving mails. Valid values: true and false | [optional] 
**ok_to_sms** | **BOOLEAN** | Applicant&#x27;s consent for receiving sms. Valid values: true and false | [optional] 

