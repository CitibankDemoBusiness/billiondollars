# SwaggerClient::PendingApplicationsForCustomerInquiryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_details** | [**Array&lt;ApplicationDetails&gt;**](ApplicationDetails.md) |  | [optional] 

