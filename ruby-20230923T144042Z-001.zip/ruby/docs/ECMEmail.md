# SwaggerClient::ECMEmail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email_address** | **String** | Email Address of the Applicant | [optional] 

