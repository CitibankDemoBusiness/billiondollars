# SwaggerClient::FinancialInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**income_details** | [**Array&lt;IncomeDetails&gt;**](IncomeDetails.md) |  | [optional] 

