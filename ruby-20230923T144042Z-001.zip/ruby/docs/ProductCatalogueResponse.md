# SwaggerClient::ProductCatalogueResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**Array&lt;Product&gt;**](Product.md) |  | 
**next_start_index** | **String** | The next start index of the next subset of products. | [optional] 

