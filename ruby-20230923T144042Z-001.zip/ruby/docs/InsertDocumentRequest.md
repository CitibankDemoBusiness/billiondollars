# SwaggerClient::InsertDocumentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document_details** | [**DocumentDetails**](DocumentDetails.md) |  | 
**control_flow_id** | **String** | Control flow id is used to control the flow for subsequent requests in the session. | 

