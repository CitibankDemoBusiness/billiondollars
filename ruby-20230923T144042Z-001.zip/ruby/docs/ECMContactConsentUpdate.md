# SwaggerClient::ECMContactConsentUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ok_to_call** | **BOOLEAN** | Applicants consent for receiving phone calls. Valid values: true and false | [optional] 
**ok_to_mail** | **BOOLEAN** | Applicants consent for receiving mails. Valid values: true and false | [optional] 

