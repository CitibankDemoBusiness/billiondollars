# SwaggerClient::ECMAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address_line1** | **String** | Address line 1. | [optional] 
**address_line2** | **String** | Address line 2. | [optional] 
**address_line3** | **String** | Address line 3. | [optional] 
**address_line4** | **String** | Address line 4. | [optional] 

