# SwaggerClient::UpdateApplicationProcessingPartnerMembershipValidationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**membership_information** | [**MembershipInformation**](MembershipInformation.md) |  | [optional] 
**sales_agent_details** | [**SalesAgentDetails**](SalesAgentDetails.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**consent_details** | [**Array&lt;ConsentDetails&gt;**](ConsentDetails.md) |  | [optional] 

