# SwaggerClient::MarketingCampaignOfferDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offer_id** | **String** | Unique offer ID associated with the offer | 

