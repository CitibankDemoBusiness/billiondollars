# SwaggerClient::UnsecuredApplicationGenerateAndSendOtpResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**masked_phone_number** | **String** | The Customers phone number having last four digits unmasked | 

