# SwaggerClient::KbaQuestionnaireResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**questionnaire** | [**Array&lt;QuestionnaireRes&gt;**](QuestionnaireRes.md) |  | [optional] 

