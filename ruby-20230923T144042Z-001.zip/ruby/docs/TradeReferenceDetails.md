# SwaggerClient::TradeReferenceDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reference_name** | **String** | Reference Name from the Trade done by the customer. | [optional] 
**relationship** | **String** | Trade Reference Relationship. This is a reference data field.Please use /v1/utilities/referenceData/{tradeReferenceRelationshipGCG} resource to get valid value of this field with description. | [optional] 
**accountant_name** | **String** | Accountant  Name from the Trade done by the customer. | [optional] 

