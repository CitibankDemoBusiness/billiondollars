# SwaggerClient::ApplicationUpdateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product** | [**ApplicationUpdateProduct**](ApplicationUpdateProduct.md) |  | [optional] 
**applicant** | [**ApplicationUpdateApplicant**](ApplicationUpdateApplicant.md) |  | [optional] 
**control_flow_id** | **String** | Control flow id is used to control the flow for subsequent requests in the session. | 

