# SwaggerClient::MembershipInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**membership_number** | **String** | Applicants 12-digit membership number. | [optional] 
**membership_type** | **String** | Applicants membership type. This is a reference data field. Please use /v1/apac/utilities/referenceData/{membershipType} resource to get valid value of this field with description. | [optional] 

