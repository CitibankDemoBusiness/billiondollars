# SwaggerClient::ApplicationUpdateMarketingConsent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**personal_data_opt_out_others_flag** | **BOOLEAN** | Opt out from use of personal data to other person/organization in direct marketing | [optional] 

