# SwaggerClient::ApplicationAddProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**ApplicationAddCreditCardProduct**](ApplicationAddCreditCardProduct.md) |  | [optional] 
**ready_credit_product** | [**ApplicationAddReadyCreditProduct**](ApplicationAddReadyCreditProduct.md) |  | [optional] 
**unsecured_loan_product** | [**ApplicationAddUnsecuredLoanProduct**](ApplicationAddUnsecuredLoanProduct.md) |  | [optional] 

