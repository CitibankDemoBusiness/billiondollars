# SwaggerClient::SupplementaryCardApplicationStatusInquiryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_status** | **String** | Application Status of an application.This is a reference data field. Please use /v1/utilities/referenceData/{applicationStatus} resource to get possible value of this field with description. | 
**application_creation_date** | **Date** | Date on which the application was created in ISO 8601 date format YYYY - MM - DD. | 

