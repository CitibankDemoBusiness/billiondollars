# SwaggerClient::ConsentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**consent_type** | **String** | Applicants consent types. This is a reference data field. Please use /v1/utilities/referenceData/{consentType} resource to get valid value of this field with description. | [optional] 
**consent_given_flag** | **BOOLEAN** | Consent flag. Valid values: true and false | [optional] 

