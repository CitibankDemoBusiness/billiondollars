# SwaggerClient::ApplicationAddRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product** | [**ApplicationAddProduct**](ApplicationAddProduct.md) |  | 
**applicant** | [**ApplicationAddApplicant**](ApplicationAddApplicant.md) |  | 

