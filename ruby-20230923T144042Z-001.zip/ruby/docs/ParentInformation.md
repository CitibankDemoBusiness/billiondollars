# SwaggerClient::ParentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**ParentName**](ParentName.md) |  | [optional] 
**address** | [**Array&lt;ParentAddress&gt;**](ParentAddress.md) |  | [optional] 
**phone** | [**Array&lt;ParentPhone&gt;**](ParentPhone.md) |  | [optional] 

