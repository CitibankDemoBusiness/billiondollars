# SwaggerClient::ECMProductUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenor** | **String** | Tenure of loan. This is a reference data field. Please use /v1/utilities/referenceData/{tenor} resource to get valid value of this field with description. | [optional] 
**credit_card_product** | [**ECMCreditCardProductUpdate**](ECMCreditCardProductUpdate.md) |  | [optional] 

