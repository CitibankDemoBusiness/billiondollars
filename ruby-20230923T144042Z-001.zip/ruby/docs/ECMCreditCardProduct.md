# SwaggerClient::ECMCreditCardProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gift_code** | **String** | A unique code that identifies the gift offered along with the product | [optional] 

