# SwaggerClient::ResponseOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**option_sequence_number** | **Integer** | Option sequence number | [optional] 
**selected_flag** | **BOOLEAN** | Identifer used to determine the if the option was selected on not. Default value is false. | [optional] 
**option_text** | **String** | Option text to be displayed to the end user. | [optional] 

