# SwaggerClient::ECMParentInformationUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_name** | [**ECMParentNameUpdate**](ECMParentNameUpdate.md) |  | [optional] 

