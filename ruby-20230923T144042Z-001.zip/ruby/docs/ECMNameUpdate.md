# SwaggerClient::ECMNameUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**local_english_given_name** | **String** | Local given name in English | [optional] 
**local_english_surname** | **String** | Local surname in English | [optional] 

