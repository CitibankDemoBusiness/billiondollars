# SwaggerClient::PendingMarketingCampaignOfferDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**campaign_id** | **String** | Unique identifier for a specific campaign being offered to the channel | [optional] 
**wave_id** | **String** | Unique identifier for the promotion under specific campaign being offered to the channel | [optional] 

