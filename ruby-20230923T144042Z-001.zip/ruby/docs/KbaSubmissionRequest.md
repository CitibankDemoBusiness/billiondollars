# SwaggerClient::KbaSubmissionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**questionnaire** | [**Array&lt;Questionnaire&gt;**](Questionnaire.md) |  | [optional] 
**control_flow_id** | **String** | Control Flow Id | [optional] 

