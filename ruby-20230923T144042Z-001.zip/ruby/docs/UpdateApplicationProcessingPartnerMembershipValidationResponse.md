# SwaggerClient::UpdateApplicationProcessingPartnerMembershipValidationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider_info** | [**Array&lt;ProviderInfo&gt;**](ProviderInfo.md) |  | [optional] 

