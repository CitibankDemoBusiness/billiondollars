# SwaggerClient::ProspectAddRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**interest** | [**Interest**](Interest.md) |  | 
**prospect** | [**Prospect**](Prospect.md) |  | 

