# SwaggerClient::ExternalCreditCardDetailsAdd

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bank_name** | **String** | Name of the bank issued the credit card. | [optional] 
**credit_card_number** | **String** | Other Credit Card Number of the applicant, to be used for bill payments | [optional] 

