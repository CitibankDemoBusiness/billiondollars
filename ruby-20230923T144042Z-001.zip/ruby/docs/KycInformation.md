# SwaggerClient::KycInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**us_tax_status** | **String** | US Tax status. This is a reference data field. Please use /v1/apac/utilities/referenceData/{usTaxStatus} resource to get possible values of this field with descriptions. You can use usTaxStatus field name as the referenceCode parameter to retrieve the values. | [optional] 
**us_tax_id** | **String** | US Tax ID | [optional] 

