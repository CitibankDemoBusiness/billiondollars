# SwaggerClient::ECMEducationUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**highest_education_level** | **String** | Highest education level of the applicant. This is a reference data field. Please use /v1/utilities/referenceData/{highestEducationLevel} resource to get valid value of this field with description. | [optional] 
**institution_name** | **String** | Institution name. This is required if applicant is a student | [optional] 

