# SwaggerClient::NotifyApplicationReleaseToNewWorkQueueRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_id** | **String** | Unique identifier for the application | 
**auto_release_point** | **String** | A trigger point of case that able to be released to next queue | 
**control_flow_id** | **String** | Control flow id is used to control the flow for subsequent requests in the session. | 

