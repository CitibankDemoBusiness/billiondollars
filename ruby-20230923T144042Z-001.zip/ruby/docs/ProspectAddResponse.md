# SwaggerClient::ProspectAddResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prospect_id** | **String** | Unique identifier for the prospect | [optional] 

