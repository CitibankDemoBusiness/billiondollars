# SwaggerClient::Email

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email_address** | **String** | Email ID | 
**ok_to_email** | **BOOLEAN** | Flag to indicate whether prospect wants to receive emails or not. Valid values: true and false | [optional] 
**is_prerferred_email_address** | **BOOLEAN** | Indicates whether this email id is preferred email for all communications. Valid values: true and false | [optional] 

