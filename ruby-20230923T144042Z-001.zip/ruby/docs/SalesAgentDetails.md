# SwaggerClient::SalesAgentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**originating_sales_agent_id** | **String** | Agent Id of the bank representative sourcing the application form. This agent might be different from the agent who is processing the application. | [optional] 
**originating_sales_branch_name** | **String** | Name of branch where the application is originally sourced. | [optional] 

