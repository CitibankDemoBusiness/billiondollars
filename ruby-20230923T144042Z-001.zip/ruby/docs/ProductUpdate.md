# SwaggerClient::ProductUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**CreditCardProductUpdate**](CreditCardProductUpdate.md) |  | [optional] 
**ready_credit_product** | [**ReadyCreditProductUpdate**](ReadyCreditProductUpdate.md) |  | [optional] 
**unsecured_loan_product** | [**UnsecuredLoanProductUpdate**](UnsecuredLoanProductUpdate.md) |  | [optional] 

