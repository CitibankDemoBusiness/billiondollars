# SwaggerClient::UnsecuredApplicationGenerateAndSendOtpRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**control_flow_id** | **String** | Control Flow ID | 

