# SwaggerClient::PresetAtmPinAddConfirmationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_id** | **String** | The unique identifier of the application. | 
**control_flow_id** | **String** | Control flow id is used to control the flow for subsequent requests in the session. | 

