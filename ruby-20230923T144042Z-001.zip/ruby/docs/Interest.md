# SwaggerClient::Interest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_group** | **String** | A unique code that identifies the product group. This is prospect selected product | 
**campaign_id** | **String** | Campaign Id. The unique identifier for campaign. | [optional] 
**wave_id** | **String** | Wave Id corresponding to campaign. | [optional] 

