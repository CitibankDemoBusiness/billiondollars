# SwaggerClient::ECMParentNameUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**full_name** | **String** | Full name of the Parent. | [optional] 

