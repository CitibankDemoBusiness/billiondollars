# SwaggerClient::ApplicationInquiryProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**ApplicationInquiryCreditCardProduct**](ApplicationInquiryCreditCardProduct.md) |  | [optional] 
**ready_credit_product** | [**ApplicationInquiryReadyCreditProduct**](ApplicationInquiryReadyCreditProduct.md) |  | [optional] 
**unsecured_loan_product** | [**ApplicationInquiryUnsecuredLoanProduct**](ApplicationInquiryUnsecuredLoanProduct.md) |  | [optional] 

