# SwaggerClient::KbaQResponseOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**option_sequence_number** | **Integer** | Option sequence number | [optional] 
**option_text** | **String** | Option text to be displayed to the end user. | [optional] 

