# SwaggerClient::ECMCountrySpecificGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**life_style_code** | **String** | Lifestyle preference of the customer. This is a reference data field. Please use /v1/apac/utilities/referenceData/{lifeStyleCode} resource to get valid value of this field with description. You can use lifeStyleCode as the referenceCode parameter to retrieve the values | [optional] 

