# SwaggerClient::ExistingCustomerCreditProductApplicationUpdateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_stage** | **String** | Application stage of an Application | 

