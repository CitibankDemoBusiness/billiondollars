# SwaggerClient::ApplicationUpdateProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**ApplicationUpdateCreditCardProduct**](ApplicationUpdateCreditCardProduct.md) |  | [optional] 
**ready_credit_product** | [**ApplicationUpdateReadyCreditProduct**](ApplicationUpdateReadyCreditProduct.md) |  | [optional] 
**unsecured_loan_product** | [**ApplicationUpdateUnsecuredLoanProduct**](ApplicationUpdateUnsecuredLoanProduct.md) |  | [optional] 

