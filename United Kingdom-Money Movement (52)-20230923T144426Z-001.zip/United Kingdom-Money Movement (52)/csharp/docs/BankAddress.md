# IO.Swagger.Model.BankAddress
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddressLine1** | **string** | Address line 1 | [optional] 
**AddressLine2** | **string** | Address line2 | [optional] 
**AddressLine3** | **string** | Address line 3 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

