# IO.Swagger.Model.ExecutePaymentInitiationTransactionAdhocMultipleTransferConfirmationAsyncRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ControlFllowId** | **string** | This is control flow ID$$O | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

