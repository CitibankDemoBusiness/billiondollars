# IO.Swagger.Model.PayeeAccountDetailsAdhocIntTransferPreprocess
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PayeeAccountNumber** | **string** | The account number of the destination account | 
**PayeeName** | **string** | Name of the payee. | [optional] 
**PayeeNickName** | **string** | The nick name of the payee assigned by the customer. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

