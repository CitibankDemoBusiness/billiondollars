# IO.Swagger.Model.Merchant
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MerchantName** | **string** | The name of the merchant. | 
**MerchantNameLocal** | **string** |  The name of the merchant in local language. | [optional] 
**MerchantNumber** | **string** | A string that uniquely identifies a merchant. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

