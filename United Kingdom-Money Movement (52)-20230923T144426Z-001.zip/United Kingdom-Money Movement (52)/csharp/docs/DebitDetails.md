# IO.Swagger.Model.DebitDetails
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransactionDebitAmount** | **double?** | The transaction debit amount. | [optional] 
**CurrencyCode** | **string** | The currency code for the debit amount in ISO 4217 format | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

