# IO.Swagger.Model.ExecutePaymentInitiationTransactionMultipleTransfersConfirmationAsyncResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransactionStatus** | **string** | This is transaction status | [optional] 
**TppBundleId** | **string** | This is bundle/ bulk id of the transactions from TPP | [optional] 
**CitiBundleId** | **string** | This is bundle/ bulk id of the transactions from CITI | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

