# IO.Swagger.Model.PayeeBankDetailsAdhocCrossBorderWireTransferPreprocess
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PayeeBankName** | **string** | Name of the bank. | [optional] 
**GlobalBankCode** | **string** | This field is to indicate the SWIFT code(Society for Worldwide Interbank Financial Telecommunication code). An internationally-recognized identification code for banks around the world. | 
**PayeeBankAddress** | [**PayeeBankAddress**](PayeeBankAddress.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

