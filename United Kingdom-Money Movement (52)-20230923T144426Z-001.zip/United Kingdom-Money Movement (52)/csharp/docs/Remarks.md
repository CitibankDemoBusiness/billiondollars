# IO.Swagger.Model.Remarks
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Remarks** | **string** | Free text that usually describes purpose of payment. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

