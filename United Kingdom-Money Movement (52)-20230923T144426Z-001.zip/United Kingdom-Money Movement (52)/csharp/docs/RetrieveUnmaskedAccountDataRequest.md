# IO.Swagger.Model.RetrieveUnmaskedAccountDataRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountInfo** | [**List&lt;AccountInfo&gt;**](AccountInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

