# IO.Swagger.Model.CreditDetails
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransactionCreditAmount** | **double?** | The transaction credit amount. | [optional] 
**CurrencyCode** | **string** | The currency code for the credit amount in ISO 4217 format | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

