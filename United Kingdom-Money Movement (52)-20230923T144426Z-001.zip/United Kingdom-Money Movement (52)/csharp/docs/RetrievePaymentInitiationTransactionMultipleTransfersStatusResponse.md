# IO.Swagger.Model.RetrievePaymentInitiationTransactionMultipleTransfersStatusResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransactionDetails** | [**List&lt;TransactionDetails&gt;**](TransactionDetails.md) |  | [optional] 
**NextStartIndex** | **string** | This will indicate more records are present, if need to be viewed this needs to  sent in the subsequent request | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

