# IO.Swagger.Model.PayeeDetailsResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InternalDomesticPayee** | [**InternalDomesticPayee**](InternalDomesticPayee.md) |  | [optional] 
**ExternalDomesticPayee** | [**ExternalDomesticPayee**](ExternalDomesticPayee.md) |  | [optional] 
**BillPaymentPayee** | [**BillPaymentPayee**](BillPaymentPayee.md) |  | [optional] 
**IbbsPayee** | [**IbbsPayee**](IbbsPayee.md) |  | [optional] 
**CitiGlobalTransferpayee** | [**CitiGlobalTransferpayee**](CitiGlobalTransferpayee.md) |  | [optional] 
**CrossBorderWireTransfersPayee** | [**CrossBorderWireTransfersPayee**](CrossBorderWireTransfersPayee.md) |  | [optional] 
**SepaTransferPayee** | [**SepaTransferPayee**](SepaTransferPayee.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

