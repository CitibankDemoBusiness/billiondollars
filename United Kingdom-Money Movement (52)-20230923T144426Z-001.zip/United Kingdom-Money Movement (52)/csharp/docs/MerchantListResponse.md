# IO.Swagger.Model.MerchantListResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MerchantInformation** | [**List&lt;MerchantInformationML&gt;**](MerchantInformationML.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

