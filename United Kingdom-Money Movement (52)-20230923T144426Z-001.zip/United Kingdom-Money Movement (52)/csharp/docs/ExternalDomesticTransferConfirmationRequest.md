# IO.Swagger.Model.ExternalDomesticTransferConfirmationRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ControlFlowId** | **string** | The control flow Id | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

