# IO.Swagger.Model.Address
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddressLine1** | **string** | AddressLine1 | [optional] 
**AddressLine2** | **string** | AddressLine2 | [optional] 
**AddressLine3** | **string** | AddressLine3 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

