# IO.Swagger.Model.ExecutePaymentInitiationTransactionAdhocMultipleTransferAsyncRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InternalDomesticDetails** | [**InternalDomesticDetails**](InternalDomesticDetails.md) |  | [optional] 
**ExternalDomesticDetails** | [**ExternalDomesticDetails**](ExternalDomesticDetails.md) |  | [optional] 
**CrossBorderDetails** | [**CrossBorderDetails**](CrossBorderDetails.md) |  | [optional] 
**Sepa** | [**Sepa**](Sepa.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

