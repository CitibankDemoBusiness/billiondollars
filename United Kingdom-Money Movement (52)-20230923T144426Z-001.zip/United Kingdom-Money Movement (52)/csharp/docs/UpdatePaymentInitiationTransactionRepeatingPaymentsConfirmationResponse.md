# IO.Swagger.Model.UpdatePaymentInitiationTransactionRepeatingPaymentsConfirmationResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountId** | **string** | The account identifier in encrypted format.Typically, this is not displayed to the customer. | 
**TransactionReferenceId** | **string** | The unique SI reference Id used to identify the payee type/ transfer from all the other transfers | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

