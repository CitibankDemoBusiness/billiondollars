# IO.Swagger.Model.FutureDatedTransaction
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ScheduleDate** | **DateTime?** | Date on which the future transaction is scheduled in ISO 8601 format YYYY-MM-DD. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

