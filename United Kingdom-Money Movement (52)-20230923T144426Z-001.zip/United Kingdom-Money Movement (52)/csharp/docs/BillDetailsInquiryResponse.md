# IO.Swagger.Model.BillDetailsInquiryResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InvoiceNumber** | **string** | This field is used to indicate the invoice number | [optional] 
**BillDetails** | [**List&lt;BillDetails&gt;**](BillDetails.md) |  | 
**CustomerMerchantReferenceDetails** | [**List&lt;CustomerMerchantReferenceDetails&gt;**](CustomerMerchantReferenceDetails.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

