# IO.Swagger.Model.ExecutePaymentInitiationTransactionAdhocMultipleTransferConfirmationAsyncResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TransactionStatus** | **string** | This is transaction status | [optional] 
**BundleId** | **string** | This is bundle/ bulk id of the transactions from TPP | [optional] 
**CitiBundleId** | **string** | This is bundle/ bulk id of the transactions from CITI | [optional] 
**TotalTransactionCount** | **string** | This is total number of transactions | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

