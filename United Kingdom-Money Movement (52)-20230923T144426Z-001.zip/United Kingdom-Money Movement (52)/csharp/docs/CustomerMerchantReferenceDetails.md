# IO.Swagger.Model.CustomerMerchantReferenceDetails
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CustomerMerchantReferenceCode** | **string** | Additional bill reference code. | 
**CustomerMerchantReferenceDescription** | **string** | The value associated with the corresponding additional Bill Reference Code. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

