# RequestCreditChargeCardFulfillmentArrangementCreditPlanEppRefundRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardDetails** | [**CardDetails**](CardDetails.md) |  |  [optional]
**originalAuthorizationCode** | **String** | Authorization Code for Original Transaction | 
**refundAuthorizationCode** | **String** | Authorization Code for Refund Transaction | 
