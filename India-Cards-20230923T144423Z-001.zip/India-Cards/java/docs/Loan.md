# Loan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanReferenceId** | **String** | Unique refrence number associated with the loan. | 
