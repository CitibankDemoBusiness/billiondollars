# DebitCardLimitDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**posSpendingLimitAmount** | **Double** | Field to indicate the limit on merchant POS spending amount per transaction |  [optional]
**dailyAtmWithdrawalLimitAmount** | **Double** | Field to indicate the limit on local ATM withdrawal amount |  [optional]
**dailyInternetPurchaseLimitAmount** | **Double** | Field to indicate the limit on internet purchase  in a day |  [optional]
