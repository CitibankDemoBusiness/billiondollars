# CreditLimitIncreaseResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseCode** | **String** | Response code.This is a reference data field. Please use /v1/apac/utilities/referenceData/{responseCode} resource to get valid value of this field with description. You can use the field name as the referenceCode parameter to retrieve the values. |  [optional]
