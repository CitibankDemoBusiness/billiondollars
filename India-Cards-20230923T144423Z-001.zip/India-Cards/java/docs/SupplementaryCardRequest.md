# SupplementaryCardRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applicants** | [**List&lt;Applicant&gt;**](Applicant.md) |  | 
