# EppResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eppOffers** | [**List&lt;EppOffers&gt;**](EppOffers.md) |  |  [optional]
