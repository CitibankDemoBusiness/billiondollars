# RetrieveCreditChargeCardFulfillmentArrangementCreditPlanOffersLoanPaymentPlansResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanPaymentPlans** | [**List&lt;LoanPaymentPlans&gt;**](LoanPaymentPlans.md) |  |  [optional]
**serviceCharge** | **Double** | Booking fee |  [optional]
**additionalServiceCharge** | **Double** | Additional service charge |  [optional]
**internalRateOfReturn** | **Double** | Internal rate of return |  [optional]
**listResponse** | [**ListResponse**](ListResponse.md) |  |  [optional]
