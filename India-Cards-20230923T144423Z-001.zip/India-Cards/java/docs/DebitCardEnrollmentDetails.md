# DebitCardEnrollmentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**internetPurchaseAccessFlag** | **Boolean** | Flag to indicate if internet purchase access is enabled or not on the debit/credit card |  [optional]
**contactlessPaymentEnrolledFlag** | **Boolean** | Flag to indicate if contact-less payment is enabled or not on the debit/credit card |  [optional]
**overseasAtmAccessAllowedFlag** | **Boolean** | This field is to indicate if overseas ATM access is allowed to the card. |  [optional]
