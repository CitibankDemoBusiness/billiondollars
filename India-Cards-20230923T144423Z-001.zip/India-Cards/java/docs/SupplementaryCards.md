# SupplementaryCards

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardId** | **String** | The card id  in encrypted format | 
**displayCardNumber** | **String** | A masked card number that can be displayed to the customer. | 
**cardStatus** | **String** | Status of the supplementary card. This is a reference data field. Please use /v1/apac/utilities/referenceData/{cardStatus} resource to get valid value of this field with description. |  [optional]
