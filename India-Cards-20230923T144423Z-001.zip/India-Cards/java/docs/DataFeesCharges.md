# DataFeesCharges

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feeChargeDetail** | [**List&lt;DataFeesChargesFeeChargeDetail&gt;**](DataFeesChargesFeeChargeDetail.md) |  |  [optional]
