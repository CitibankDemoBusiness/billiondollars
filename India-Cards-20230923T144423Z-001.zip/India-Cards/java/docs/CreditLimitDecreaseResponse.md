# CreditLimitDecreaseResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**controlFlowId** | **String** | It is used to control the flow for subsequent requests in the session. |  [optional]
**creditLimitdDecreaseReferenceId** | **String** | Unique Reference Id for the request for credit limit decrease request. |  [optional]
**customerConsentRequiredFlag** | **Boolean** | This refers that consent is required from customer as new limit lower than the outstanding request. |  [optional]
