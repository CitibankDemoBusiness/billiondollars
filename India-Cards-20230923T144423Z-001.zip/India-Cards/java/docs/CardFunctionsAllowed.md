# CardFunctionsAllowed

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardFunction** | **String** | Card function. This is a reference data field. Please use /v1/apac/utilities/referenceData/{cardFunction} resource to get valid value of this field with description. You can use the field name as the referenceCode parameter to retrieve the values. |  [optional]
