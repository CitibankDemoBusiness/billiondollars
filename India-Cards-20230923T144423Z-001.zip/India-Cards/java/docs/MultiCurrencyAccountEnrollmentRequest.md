# MultiCurrencyAccountEnrollmentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | [**List&lt;Account&gt;**](Account.md) |  |  [optional]
