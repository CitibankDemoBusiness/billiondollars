# UpdateCreditChargeCardCorporateCardsCreditLimitResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uniqueReferenceNumber** | **String** | Unique reference ID associated with the Limit Increae Request |  [optional]
