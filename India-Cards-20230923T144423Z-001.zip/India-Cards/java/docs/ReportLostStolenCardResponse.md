# ReportLostStolenCardResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceId** | **String** | Unique reference ID associated with the lost or stolen card request. |  [optional]
