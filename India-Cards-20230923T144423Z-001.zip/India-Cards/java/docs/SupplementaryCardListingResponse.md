# SupplementaryCardListingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplementaryCards** | [**List&lt;SupplementaryCards&gt;**](SupplementaryCards.md) |  |  [optional]
