# CvvVerificationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**encryptedCvv** | **String** | CVV number in encrypted format | 
**cardId** | **String** | The card id in encrypted format | 
