# ChangeAtmPinRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**controlFlowId** | **String** | Control flow id is used to control the flow for subsequent requests in the session. | 
**cardId** | **String** | Hashed card number of the customer. | 
**newPin** | **String** | New PIN in encrypted format | 
