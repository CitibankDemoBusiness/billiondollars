# CountryCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryCode** | **String** | Customers travelling country code in ISO 3166 alpha-2 format | 
