# DataRequirements

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requirementDetail** | [**List&lt;DataRequirementsRequirementDetail&gt;**](DataRequirementsRequirementDetail.md) |  |  [optional]
