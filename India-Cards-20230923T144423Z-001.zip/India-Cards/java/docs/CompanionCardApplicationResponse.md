# CompanionCardApplicationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionReferenceId** | **String** | Unique reference Id associated with the new companion card request transaction |  [optional]
