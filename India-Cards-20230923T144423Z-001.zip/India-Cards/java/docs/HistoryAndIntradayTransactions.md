# HistoryAndIntradayTransactions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nextStartIndex** | **String** | For pagination - the starting index for retrieving the next page/batch of records. |  [optional]
**moreIndicator** | **String** | This field indicates that more records are available for retrieval. |  [optional]
**numberOfTransactions** | **Integer** | Number of Transactions |  [optional]
**historyAndIntradayTransactionRecords** | [**List&lt;HistoryAndIntradayTransactionRecords&gt;**](HistoryAndIntradayTransactionRecords.md) |  |  [optional]
