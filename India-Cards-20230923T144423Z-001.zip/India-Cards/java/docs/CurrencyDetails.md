# CurrencyDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencyCode** | **String** | The currency code in ISO 4217 format | 
**currencyName** | **String** | The currency name. | 
