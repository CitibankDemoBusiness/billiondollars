# RequestCreditChargeCardFulfillmentArrangementCorporateCardsDamageReplacementResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uniqueReferenceNumber** | **String** | Unique reference Identifier Number |  [optional]
