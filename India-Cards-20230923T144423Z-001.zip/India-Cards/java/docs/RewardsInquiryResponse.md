# RewardsInquiryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rewardAccounts** | [**List&lt;RewardAccount&gt;**](RewardAccount.md) |  | 
