# CreditLimitDecreaseConsentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**controlFlowId** | **String** | It is used to control the flow for subsequent requests in the session. | 
