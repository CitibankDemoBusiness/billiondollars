# TransactionReferenceId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionReferenceId** | **String** | Reference Id to uniquely identify the transaction. Applicable only for EPP of type TRANSACTION. |  [optional]
