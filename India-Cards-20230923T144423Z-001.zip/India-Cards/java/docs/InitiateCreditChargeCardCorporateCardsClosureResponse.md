# InitiateCreditChargeCardCorporateCardsClosureResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cancellationReferenceId** | **String** | Unique Reference Id for the request for account closure. |  [optional]
