# MultiCurrencyAccountEnrollmentWithCurrencyResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountDetails** | [**AccountDetails**](AccountDetails.md) |  |  [optional]
