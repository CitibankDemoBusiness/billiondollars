# SupplementaryCardResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applicationId** | **String** | Unique identifier for the supplementary card application | 
