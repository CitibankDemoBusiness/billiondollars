# CountrySpecificAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streetName** | **String** | Applicant&#x27;s street Name | 
**streetType** | **String** | Applicant&#x27;s street Type.This is a reference data field. Please use /utilities/referenceData/{streetType} resource to get valid values of this field with descriptions. | 
**streetNumber** | **String** | Applicant&#x27;s street Number | 
**unitNumber** | **String** | Applicant&#x27;s unit Number |  [optional]
