# EppRepaymentScheuleResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eppAmortizationSchedule** | [**List&lt;EppAmortizationSchedule&gt;**](EppAmortizationSchedule.md) |  |  [optional]
**totalLoanCost** | **Double** | Principal and total Interest amount to be paid by borrower for the loan. |  [optional]
