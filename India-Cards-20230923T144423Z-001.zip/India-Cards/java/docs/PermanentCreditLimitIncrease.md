# PermanentCreditLimitIncrease

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardId** | **String** | Unique Id of the card in encrypted format. | 
**requestedCreditLimitAmount** | **Double** | Customers preferred revised credit limit. This is the combined limit  shared with all the existing credit cards of the customer | 
