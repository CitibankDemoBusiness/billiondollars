# PartnerCardListingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**partnerCardDetails** | [**List&lt;PartnerCardDetails&gt;**](PartnerCardDetails.md) |  |  [optional]
