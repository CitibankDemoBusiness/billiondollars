# DomesticTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**atmTransactionLimitToggleIndicator** | **String** | DomesticSingleATMTransactionLimitToggleFlag |  [optional]
**atmTransactionLimitAmount** | **Double** | DomesticSingleATMTransactionLimit |  [optional]
**contactlessTxnLimitToggleIndicator** | **String** | DomesticSingleContactlessTransactionLimitToggleFlag |  [optional]
**contactlessTransactionLimitAmount** | **Double** | DomesticSingleContactlessTransactionLimit |  [optional]
**contactPosTxnLimitToggleIndicator** | **String** | DomesticSingleContactPOSTransactionLimitToggleFlag |  [optional]
**contactPosTransactionLimitAmount** | **Double** | DomesticSingleContactPOSTransactionLimit |  [optional]
**nonPosTxnLimitToggleIndicator** | **String** | DomesticSingleNonPOSTransactionLimitToggleFlag |  [optional]
**nonPosTransactionLimitAmount** | **Double** | DomesticSingleNonPOSTransactionLimit |  [optional]
