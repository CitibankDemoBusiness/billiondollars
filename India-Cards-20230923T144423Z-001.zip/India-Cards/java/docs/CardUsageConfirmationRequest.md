# CardUsageConfirmationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**controlFlowId** | **String** | Control Flow Id | 
