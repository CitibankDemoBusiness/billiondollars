# InternationalTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**atmTransactionLimitToggleIndicator** | **String** | InternationalSingleATMTransactionLimitToggleFlag |  [optional]
**atmTransactionLimitAmount** | **Double** | InternationalSingleATMTransactionLimit |  [optional]
**contactlessTxnLimitToggleIndicator** | **String** | InternationalSingleContactlessTransactionLimitToggleFlag |  [optional]
**contactlessTransactionLimitAmount** | **Double** | InternationalSingleContactlessTransactionLimit |  [optional]
**contactPosTxnLimitToggleIndicator** | **String** | InternationalSingleContactPOSTransactionLimitToggleFlag |  [optional]
**contactPosTransactionLimitAmount** | **Double** | InternationalSingleContactPOSTransactionLimit |  [optional]
**nonPosTxnLimitToggleIndicator** | **String** | InternationalSingleNonPOSTransactionLimitToggleFlag |  [optional]
**nonPosTransactionLimitAmount** | **Double** | InternationalSingleNonPOSTransactionLimit |  [optional]
