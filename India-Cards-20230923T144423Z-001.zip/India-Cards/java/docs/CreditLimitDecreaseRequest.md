# CreditLimitDecreaseRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardId** | **String** | The card id  in encrypted format. | 
**requestedCreditLimitAmount** | **Double** | Customer&#x27;s preferred revised credit limit. This is the combined limit  shared with all the existing credit cards of the customer. | 
