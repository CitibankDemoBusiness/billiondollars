# RetrieveCreditChargeCardFulfillmentArrangementCreditPlanLoansResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanAccount** | [**List&lt;LoanAccount&gt;**](LoanAccount.md) |  |  [optional]
