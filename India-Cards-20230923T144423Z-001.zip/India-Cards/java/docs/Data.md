# Data

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productDetails** | [**DataProductDetails**](DataProductDetails.md) |  |  [optional]
**requirements** | [**DataRequirements**](DataRequirements.md) |  |  [optional]
**productOfferings** | [**DataProductOfferings**](DataProductOfferings.md) |  |  [optional]
**feesCharges** | [**DataFeesCharges**](DataFeesCharges.md) |  |  [optional]
**promotions** | [**DataPromotions**](DataPromotions.md) |  |  [optional]
