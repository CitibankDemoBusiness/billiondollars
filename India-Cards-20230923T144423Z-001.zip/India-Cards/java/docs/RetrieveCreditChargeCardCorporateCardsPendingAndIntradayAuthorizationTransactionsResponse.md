# RetrieveCreditChargeCardCorporateCardsPendingAndIntradayAuthorizationTransactionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pendingAuthorizationTransactions** | [**PendingAuthorizationTransactions**](PendingAuthorizationTransactions.md) |  |  [optional]
**historyAndIntradayTransactions** | [**HistoryAndIntradayTransactions**](HistoryAndIntradayTransactions.md) |  |  [optional]
