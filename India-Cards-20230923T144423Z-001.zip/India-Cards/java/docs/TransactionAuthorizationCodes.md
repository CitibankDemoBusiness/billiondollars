# TransactionAuthorizationCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionAuthorizationCode** | **String** | Transaction authorization code is a unique to a sales credit card transaction to indicate that the sale has been authorized. |  [optional]
