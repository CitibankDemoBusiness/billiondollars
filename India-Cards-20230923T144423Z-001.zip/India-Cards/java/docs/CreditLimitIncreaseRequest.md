# CreditLimitIncreaseRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**permanentCreditLimitIncrease** | [**PermanentCreditLimitIncrease**](PermanentCreditLimitIncrease.md) |  |  [optional]
**temporaryCreditLimitIncrease** | [**TemporaryCreditLimitIncrease**](TemporaryCreditLimitIncrease.md) |  |  [optional]
