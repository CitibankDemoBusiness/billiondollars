# RetrieveCreditChargeCardFulfillmentArrangementCreditPlanConsolidatePreLoginWithValidationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**initialFeeAmount** | **Double** | First month fee/interest charge incurred from booking date to next statement cycle date |  [optional]
**closureInterestAmount** | **Double** | Closure Interest accrued from last cycle/booking date till date, to be charged for each of the loans getting closed due to Top up post merger |  [optional]
