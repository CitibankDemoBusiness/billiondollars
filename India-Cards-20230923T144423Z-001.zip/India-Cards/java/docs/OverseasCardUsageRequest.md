# OverseasCardUsageRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activationRequest** | [**ActivationRequest**](ActivationRequest.md) |  |  [optional]
**overseasCardUsageOption** | **String** | Activation code for overseas card Usage. This is a reference data field. Please use /v1/apac/utilities/referenceData/{overseasCardUsageOption} resource to get valid value of this field with description. You can use the field name as the referenceCode parameter to retrieve the values | 
