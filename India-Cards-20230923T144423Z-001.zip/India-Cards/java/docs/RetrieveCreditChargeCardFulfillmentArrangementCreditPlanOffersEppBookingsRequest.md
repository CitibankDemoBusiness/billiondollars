# RetrieveCreditChargeCardFulfillmentArrangementCreditPlanOffersEppBookingsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanAmount** | **Double** | Loan amount for easy payment plan booking. |  [optional]
**tenor** | [**BigDecimal**](BigDecimal.md) | Tenure of loan in months. | 
