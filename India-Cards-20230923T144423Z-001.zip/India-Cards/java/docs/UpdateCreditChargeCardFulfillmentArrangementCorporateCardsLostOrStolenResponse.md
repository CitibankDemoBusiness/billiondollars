# UpdateCreditChargeCardFulfillmentArrangementCorporateCardsLostOrStolenResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uniqueReferenceIdentifier** | **String** | Unique reference Identifier Number$$M | 
