# ConsentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**consentType** | **String** | Applicant&#x27;s consent types. This is a reference data field. Please use /v1/apac/utilities/referenceData/{consentType} resource to get valid value of this field with description. | 
**consentGivenFlag** | **Boolean** | Consent flag. Valid values: true and false | 
