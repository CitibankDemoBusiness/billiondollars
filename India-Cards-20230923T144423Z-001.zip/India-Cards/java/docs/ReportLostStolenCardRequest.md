# ReportLostStolenCardRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**replacementIndicator** | **String** | Indicator to specify whether customer requires card replacement.This is a reference data field. Please use /v1/apac/utilities/referenceData/{replacementIndicator} resource to get valid value of this field with description. You can use the field name as the referenceCode parameter to retrieve the values. |  [optional]
