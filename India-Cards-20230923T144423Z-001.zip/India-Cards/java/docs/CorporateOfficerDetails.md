# CorporateOfficerDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emailAddress** | **String** | emailAddress of the officer | 
**corporateOfficerId** | **String** | Customer Number of the Officer | 
**corporateOfficerType** | **String** | corporateofficerType. This is a reference data field. Please use /v1/utilities/referenceData/{corporateOfficerType} resource to get possible values of this field with descriptions | 
