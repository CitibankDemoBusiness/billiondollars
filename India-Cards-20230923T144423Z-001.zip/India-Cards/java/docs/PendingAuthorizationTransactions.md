# PendingAuthorizationTransactions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberOfTransactions** | **Integer** | Total Number of Transactions |  [optional]
**moreIndicator** | **String** | This field indicates that more records are available for retrieval. Y &#x3D; more records are available for retrieval, N &#x3D; no more records are available for retrieval |  [optional]
**nextStartIndex** | **String** | This field indicates the starting index for retrieving the next page/batch of records. |  [optional]
**pendingAuthorizationTransactionRecords** | [**List&lt;PendingAuthorizationTransactionRecords&gt;**](PendingAuthorizationTransactionRecords.md) |  |  [optional]
