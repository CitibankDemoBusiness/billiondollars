# Name

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**surname** | **String** | Surname/last name of the applicant | 
**givenName** | **String** | Given/first name of the applicant | 
**middleName** | **String** | Middle name of the applicant |  [optional]
**salutation** | **String** | Salutation. This is a reference data field. Please use /v1/apac/utilities/referenceData/{salutation} resource to get valid value of this field with description. | 
