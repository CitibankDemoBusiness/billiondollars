# CreditLimitDecreaseConsentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creditLimitdDecreaseReferenceId** | **String** | Unique Reference Id for the request for credit limit decrease request. | 
