# ProductResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**Meta**](Meta.md) |  |  [optional]
**data** | [**List&lt;Data&gt;**](Data.md) |  |  [optional]
