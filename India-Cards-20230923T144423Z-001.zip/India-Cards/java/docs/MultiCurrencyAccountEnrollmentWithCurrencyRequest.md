# MultiCurrencyAccountEnrollmentWithCurrencyRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencyCode** | **String** | Currency code  in ISO 4217 format, which needs to be added to multi currency account by creating new account for that foreign currency | 
**accountId** | **String** | The customer account identifier in encrypted format |  [optional]
