# PendingAuthorizationTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nextStartIndex** | **String** | For pagination - the starting index for retrieving the next page/batch of records. |  [optional]
**moreIndicator** | **String** | This field is used for  pagination, it indicates that more records are available for retrieval. |  [optional]
