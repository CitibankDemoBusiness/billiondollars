# ResetAtmPinConfirmationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**posTransactionPinEnablementStatus** | **String** | To show success/failure to the channel, whether Request for Enabling / Disabling of PIN is successfully done or not |  [optional]
