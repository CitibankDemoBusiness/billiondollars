# OverseasTravelPlanInquiryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**travelPlan** | [**List&lt;TravelPlan&gt;**](TravelPlan.md) |  |  [optional]
