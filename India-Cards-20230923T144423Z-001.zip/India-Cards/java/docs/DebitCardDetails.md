# DebitCardDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**debitCardEnrollmentDetails** | [**DebitCardEnrollmentDetails**](DebitCardEnrollmentDetails.md) |  |  [optional]
**debitCardLimitDetails** | [**DebitCardLimitDetails**](DebitCardLimitDetails.md) |  |  [optional]
