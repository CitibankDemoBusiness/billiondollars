# CreditCardDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creditCardLimitDetails** | [**CreditCardLimitDetails**](CreditCardLimitDetails.md) |  |  [optional]
