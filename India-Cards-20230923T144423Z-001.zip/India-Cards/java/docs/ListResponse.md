# ListResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**moreIndicator** | **String** | M - Indicates more rows present in list Space - Indicates no more rows in the list. M will be converted to Y at ESB |  [optional]
**nextStartIndex** | **String** | Ending index of the list |  [optional]
**size** | **Integer** | Size of the list |  [optional]
