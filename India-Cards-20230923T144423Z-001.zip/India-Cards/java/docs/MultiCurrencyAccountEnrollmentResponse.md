# MultiCurrencyAccountEnrollmentResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardId** | **String** | The customer card identifier in encrypted format | 
**enrollmentStatusFlag** | **Boolean** | This field is to indicate if the card is enrolled for multi currency account or not. |  [optional]
**accountDetails** | [**List&lt;AccountDetails&gt;**](AccountDetails.md) |  |  [optional]
