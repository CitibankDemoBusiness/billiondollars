# UpdateIssuedDeviceAllocationDevicePfidResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseTimestamp** | **String** | Date time in MMDDYYYYHHMMSS Format. | 
