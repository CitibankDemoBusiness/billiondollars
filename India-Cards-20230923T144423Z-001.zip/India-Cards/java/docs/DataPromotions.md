# DataPromotions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startDate** | [**LocalDate**](LocalDate.md) | Promotion start date |  [optional]
**endDate** | [**LocalDate**](LocalDate.md) | Promotion end date |  [optional]
**description** | **String** | Description of promotion |  [optional]
**url** | **String** | Absolute URL to access further detail on promotion |  [optional]
