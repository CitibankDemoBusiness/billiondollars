# RewardsInquiryRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardDetails** | [**List&lt;CardDetails&gt;**](CardDetails.md) |  |  [optional]
