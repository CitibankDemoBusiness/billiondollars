# RetrieveCreditChargeCardFulfillmentArrangementCreditCardStatusResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cardStatus** | **String** | This refers to the Card Status. This is a reference data field. Please use /v1/apac/utilities/referenceData/{cardStatus} resource to get valid value of this field with description | 
