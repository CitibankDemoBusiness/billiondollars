# TransactionReferenceId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transaction_reference_id** | **str** | Reference Id to uniquely identify the transaction. Applicable only for EPP of type TRANSACTION. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

