# UpdateIssuedDeviceAllocationDevicePfidResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response_timestamp** | **str** | Date time in MMDDYYYYHHMMSS Format. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

