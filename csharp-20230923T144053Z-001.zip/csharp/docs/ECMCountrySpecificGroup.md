# IO.Swagger.Model.ECMCountrySpecificGroup
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LifeStyleCode** | **string** | Lifestyle preference of the customer. This is a reference data field. Please use /v1/apac/utilities/referenceData/{lifeStyleCode} resource to get valid value of this field with description. You can use lifeStyleCode as the referenceCode parameter to retrieve the values | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

