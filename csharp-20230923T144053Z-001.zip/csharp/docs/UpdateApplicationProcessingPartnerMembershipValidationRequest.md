# IO.Swagger.Model.UpdateApplicationProcessingPartnerMembershipValidationRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MembershipInformation** | [**MembershipInformation**](MembershipInformation.md) |  | [optional] 
**SalesAgentDetails** | [**SalesAgentDetails**](SalesAgentDetails.md) |  | [optional] 
**Product** | [**Product**](Product.md) |  | [optional] 
**ConsentDetails** | [**List&lt;ConsentDetails&gt;**](ConsentDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

