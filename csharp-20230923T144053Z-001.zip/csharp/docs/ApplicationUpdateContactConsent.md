# IO.Swagger.Model.ApplicationUpdateContactConsent
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OkToCall** | **bool?** | Applicant&#x27;s consent for receiving phone calls. Valid values: true and false | [optional] 
**OkToMail** | **bool?** | Applicant&#x27;s consent for receiving mails. Valid values: true and false | [optional] 
**OkToSms** | **bool?** | Applicant&#x27;s consent for receiving sms. Valid values: true and false | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

