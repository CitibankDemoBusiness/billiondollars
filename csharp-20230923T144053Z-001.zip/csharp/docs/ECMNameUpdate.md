# IO.Swagger.Model.ECMNameUpdate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LocalEnglishGivenName** | **string** | Local given name in English | [optional] 
**LocalEnglishSurname** | **string** | Local surname in English | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

