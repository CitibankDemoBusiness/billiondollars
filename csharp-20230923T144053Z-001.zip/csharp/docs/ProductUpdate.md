# IO.Swagger.Model.ProductUpdate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreditCardProduct** | [**CreditCardProductUpdate**](CreditCardProductUpdate.md) |  | [optional] 
**ReadyCreditProduct** | [**ReadyCreditProductUpdate**](ReadyCreditProductUpdate.md) |  | [optional] 
**UnsecuredLoanProduct** | [**UnsecuredLoanProductUpdate**](UnsecuredLoanProductUpdate.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

