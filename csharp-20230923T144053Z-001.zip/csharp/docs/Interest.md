# IO.Swagger.Model.Interest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProductGroup** | **string** | A unique code that identifies the product group. This is prospect selected product | 
**CampaignId** | **string** | Campaign Id. The unique identifier for campaign. | [optional] 
**WaveId** | **string** | Wave Id corresponding to campaign. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

