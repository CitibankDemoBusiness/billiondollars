# IO.Swagger.Model.UnsecuredApplicationValidateOtpRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OtpToken** | **string** | Encrypted OTP Token to be validated | 
**ControlFlowId** | **string** | Control Flow Id | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

