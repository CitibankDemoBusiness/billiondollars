# IO.Swagger.Model.KbaQuestionnaireResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Questionnaire** | [**List&lt;QuestionnaireRes&gt;**](QuestionnaireRes.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

