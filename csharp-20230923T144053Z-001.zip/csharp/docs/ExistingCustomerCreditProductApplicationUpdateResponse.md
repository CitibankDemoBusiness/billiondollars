# IO.Swagger.Model.ExistingCustomerCreditProductApplicationUpdateResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApplicationStage** | **string** | Application stage of an Application | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

