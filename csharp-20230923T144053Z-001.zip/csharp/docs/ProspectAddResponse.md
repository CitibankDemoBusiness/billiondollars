# IO.Swagger.Model.ProspectAddResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProspectId** | **string** | Unique identifier for the prospect | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

