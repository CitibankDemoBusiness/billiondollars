# IO.Swagger.Model.ParentInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | [**ParentName**](ParentName.md) |  | [optional] 
**Address** | [**List&lt;ParentAddress&gt;**](ParentAddress.md) |  | [optional] 
**Phone** | [**List&lt;ParentPhone&gt;**](ParentPhone.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

