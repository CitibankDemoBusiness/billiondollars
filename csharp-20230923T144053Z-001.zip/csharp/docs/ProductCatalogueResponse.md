# IO.Swagger.Model.ProductCatalogueResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Products** | [**List&lt;Product&gt;**](Product.md) |  | 
**NextStartIndex** | **string** | The next start index of the next subset of products. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

