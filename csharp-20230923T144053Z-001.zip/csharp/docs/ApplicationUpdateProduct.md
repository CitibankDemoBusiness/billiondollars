# IO.Swagger.Model.ApplicationUpdateProduct
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreditCardProduct** | [**ApplicationUpdateCreditCardProduct**](ApplicationUpdateCreditCardProduct.md) |  | [optional] 
**ReadyCreditProduct** | [**ApplicationUpdateReadyCreditProduct**](ApplicationUpdateReadyCreditProduct.md) |  | [optional] 
**UnsecuredLoanProduct** | [**ApplicationUpdateUnsecuredLoanProduct**](ApplicationUpdateUnsecuredLoanProduct.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

