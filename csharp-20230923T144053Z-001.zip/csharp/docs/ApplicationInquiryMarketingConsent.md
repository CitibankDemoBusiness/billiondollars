# IO.Swagger.Model.ApplicationInquiryMarketingConsent
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PersonalDataOptOutFlag** | **bool?** | Opt out from use of personal data in direct marketing | [optional] 
**PersonalDataOptOutOthersFlag** | **bool?** | Opt out from use of personal data to other person in direct marketing | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

