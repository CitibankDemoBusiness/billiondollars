# IO.Swagger.Model.ECMContactConsentUpdate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OkToCall** | **bool?** | Applicants consent for receiving phone calls. Valid values: true and false | [optional] 
**OkToMail** | **bool?** | Applicants consent for receiving mails. Valid values: true and false | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

