# IO.Swagger.Model.PendingMarketingCampaignOfferDetails
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CampaignId** | **string** | Unique identifier for a specific campaign being offered to the channel | [optional] 
**WaveId** | **string** | Unique identifier for the promotion under specific campaign being offered to the channel | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

