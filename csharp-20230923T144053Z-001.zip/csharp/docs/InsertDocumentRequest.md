# IO.Swagger.Model.InsertDocumentRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DocumentDetails** | [**DocumentDetails**](DocumentDetails.md) |  | 
**ControlFlowId** | **string** | Control flow id is used to control the flow for subsequent requests in the session. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

