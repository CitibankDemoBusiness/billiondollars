# IO.Swagger.Model.PendingApplicationsForCustomerInquiryResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApplicationDetails** | [**List&lt;ApplicationDetails&gt;**](ApplicationDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

