# IO.Swagger.Model.ApplicationAddProduct
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreditCardProduct** | [**ApplicationAddCreditCardProduct**](ApplicationAddCreditCardProduct.md) |  | [optional] 
**ReadyCreditProduct** | [**ApplicationAddReadyCreditProduct**](ApplicationAddReadyCreditProduct.md) |  | [optional] 
**UnsecuredLoanProduct** | [**ApplicationAddUnsecuredLoanProduct**](ApplicationAddUnsecuredLoanProduct.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

