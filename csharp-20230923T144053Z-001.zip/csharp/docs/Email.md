# IO.Swagger.Model.Email
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EmailAddress** | **string** | Email ID | 
**OkToEmail** | **bool?** | Flag to indicate whether prospect wants to receive emails or not. Valid values: true and false | [optional] 
**IsPrerferredEmailAddress** | **bool?** | Indicates whether this email id is preferred email for all communications. Valid values: true and false | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

