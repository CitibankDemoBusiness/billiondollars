# IO.Swagger.Model.ExternalCreditCardDetailsAdd
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BankName** | **string** | Name of the bank issued the credit card. | [optional] 
**CreditCardNumber** | **string** | Other Credit Card Number of the applicant, to be used for bill payments | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

