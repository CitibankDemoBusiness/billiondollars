# ParentInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**\Swagger\Client\Model\ParentName**](ParentName.md) |  | [optional] 
**address** | [**\Swagger\Client\Model\ParentAddress[]**](ParentAddress.md) |  | [optional] 
**phone** | [**\Swagger\Client\Model\ParentPhone[]**](ParentPhone.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

