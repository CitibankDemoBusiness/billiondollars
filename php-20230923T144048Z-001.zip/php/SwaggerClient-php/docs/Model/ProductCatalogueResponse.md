# ProductCatalogueResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**\Swagger\Client\Model\Product[]**](Product.md) |  | 
**next_start_index** | **string** | The next start index of the next subset of products. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

