# ApplicantUpdateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**control_flow_id** | **string** | It is used to control the flow for subsequent requests in the session. | 
**applicant** | [**\Swagger\Client\Model\ApplicantUpdateApplicant**](ApplicantUpdateApplicant.md) |  | 
**credit_card_product** | [**\Swagger\Client\Model\ApplicantUpdateCreditCardProduct**](ApplicantUpdateCreditCardProduct.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

