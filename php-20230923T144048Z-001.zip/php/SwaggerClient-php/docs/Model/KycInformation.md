# KycInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**us_tax_status** | **string** | US Tax status. This is a reference data field. Please use /v1/apac/utilities/referenceData/{usTaxStatus} resource to get possible values of this field with descriptions. You can use usTaxStatus field name as the referenceCode parameter to retrieve the values. | [optional] 
**us_tax_id** | **string** | US Tax ID | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

