# ECMProductUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenor** | **string** | Tenure of loan. This is a reference data field. Please use /v1/utilities/referenceData/{tenor} resource to get valid value of this field with description. | [optional] 
**credit_card_product** | [**\Swagger\Client\Model\ECMCreditCardProductUpdate**](ECMCreditCardProductUpdate.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

