# ProspectAddRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**interest** | [**\Swagger\Client\Model\Interest**](Interest.md) |  | 
**prospect** | [**\Swagger\Client\Model\Prospect**](Prospect.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

