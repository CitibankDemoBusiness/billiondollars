# ECMParentNameUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**full_name** | **string** | Full name of the Parent. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

