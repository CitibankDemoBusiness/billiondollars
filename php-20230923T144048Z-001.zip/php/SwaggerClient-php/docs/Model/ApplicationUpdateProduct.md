# ApplicationUpdateProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**\Swagger\Client\Model\ApplicationUpdateCreditCardProduct**](ApplicationUpdateCreditCardProduct.md) |  | [optional] 
**ready_credit_product** | [**\Swagger\Client\Model\ApplicationUpdateReadyCreditProduct**](ApplicationUpdateReadyCreditProduct.md) |  | [optional] 
**unsecured_loan_product** | [**\Swagger\Client\Model\ApplicationUpdateUnsecuredLoanProduct**](ApplicationUpdateUnsecuredLoanProduct.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

