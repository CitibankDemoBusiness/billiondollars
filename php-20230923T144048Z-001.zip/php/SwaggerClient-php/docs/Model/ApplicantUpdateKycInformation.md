# ApplicantUpdateKycInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self_public_figure_declaration_flag** | **bool** | Flag for self declaration if applicant is public figure. Valid values: true and false | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

