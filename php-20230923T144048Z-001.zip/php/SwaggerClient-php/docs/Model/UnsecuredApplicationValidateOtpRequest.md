# UnsecuredApplicationValidateOtpRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**otp_token** | **string** | Encrypted OTP Token to be validated | 
**control_flow_id** | **string** | Control Flow Id | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

