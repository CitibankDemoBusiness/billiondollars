# NotifyApplicationReleaseToNewWorkQueueRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_id** | **string** | Unique identifier for the application | 
**auto_release_point** | **string** | A trigger point of case that able to be released to next queue | 
**control_flow_id** | **string** | Control flow id is used to control the flow for subsequent requests in the session. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

