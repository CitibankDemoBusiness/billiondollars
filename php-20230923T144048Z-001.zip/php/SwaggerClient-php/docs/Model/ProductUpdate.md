# ProductUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**\Swagger\Client\Model\CreditCardProductUpdate**](CreditCardProductUpdate.md) |  | [optional] 
**ready_credit_product** | [**\Swagger\Client\Model\ReadyCreditProductUpdate**](ReadyCreditProductUpdate.md) |  | [optional] 
**unsecured_loan_product** | [**\Swagger\Client\Model\UnsecuredLoanProductUpdate**](UnsecuredLoanProductUpdate.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

