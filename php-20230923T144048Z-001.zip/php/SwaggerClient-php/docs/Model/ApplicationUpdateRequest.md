# ApplicationUpdateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product** | [**\Swagger\Client\Model\ApplicationUpdateProduct**](ApplicationUpdateProduct.md) |  | [optional] 
**applicant** | [**\Swagger\Client\Model\ApplicationUpdateApplicant**](ApplicationUpdateApplicant.md) |  | [optional] 
**control_flow_id** | **string** | Control flow id is used to control the flow for subsequent requests in the session. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

