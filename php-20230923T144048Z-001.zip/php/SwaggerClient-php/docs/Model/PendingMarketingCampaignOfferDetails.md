# PendingMarketingCampaignOfferDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**campaign_id** | **string** | Unique identifier for a specific campaign being offered to the channel | [optional] 
**wave_id** | **string** | Unique identifier for the promotion under specific campaign being offered to the channel | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

