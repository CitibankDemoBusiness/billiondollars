# ECMNameUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**local_english_given_name** | **string** | Local given name in English | [optional] 
**local_english_surname** | **string** | Local surname in English | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

