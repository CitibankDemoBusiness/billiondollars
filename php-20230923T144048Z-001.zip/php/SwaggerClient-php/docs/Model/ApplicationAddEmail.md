# ApplicationAddEmail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email_address** | **string** | Applicant&#x27;s email address | 
**ok_to_email** | **bool** | Applicant&#x27;s consent for receiving email. Valid values: true and false | [optional] 
**is_preferred_email_address** | **bool** | Flag to mark preferred email. Valid values: true and false | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

