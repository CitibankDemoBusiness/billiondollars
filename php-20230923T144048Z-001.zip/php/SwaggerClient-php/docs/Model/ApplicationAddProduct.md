# ApplicationAddProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credit_card_product** | [**\Swagger\Client\Model\ApplicationAddCreditCardProduct**](ApplicationAddCreditCardProduct.md) |  | [optional] 
**ready_credit_product** | [**\Swagger\Client\Model\ApplicationAddReadyCreditProduct**](ApplicationAddReadyCreditProduct.md) |  | [optional] 
**unsecured_loan_product** | [**\Swagger\Client\Model\ApplicationAddUnsecuredLoanProduct**](ApplicationAddUnsecuredLoanProduct.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

