# ECMProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_code** | **string** | A unique code that identifies the product. | 
**source_code** | **string** | A source code to identify the product | 
**organization** | **string** | Card issuing organization name | 
**logo** | **string** | Product logo to identify the product | 
**credit_card_product** | [**\Swagger\Client\Model\ECMCreditCardProduct**](ECMCreditCardProduct.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

