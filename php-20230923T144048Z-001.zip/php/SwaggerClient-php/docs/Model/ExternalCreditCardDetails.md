# ExternalCreditCardDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bank_name** | **string** | Name of the bank issued the credit card. | [optional] 
**display_card_number** | **string** | Applicant&#x27;s other Credit Card Number in masked format, to be used for bill payments | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

