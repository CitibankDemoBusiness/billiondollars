# UpdateApplicationProcessingPartnerMembershipValidationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**membership_information** | [**\Swagger\Client\Model\MembershipInformation**](MembershipInformation.md) |  | [optional] 
**sales_agent_details** | [**\Swagger\Client\Model\SalesAgentDetails**](SalesAgentDetails.md) |  | [optional] 
**product** | [**\Swagger\Client\Model\Product**](Product.md) |  | [optional] 
**consent_details** | [**\Swagger\Client\Model\ConsentDetails[]**](ConsentDetails.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

