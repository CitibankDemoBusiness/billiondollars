# ECMContactConsentUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ok_to_call** | **bool** | Applicants consent for receiving phone calls. Valid values: true and false | [optional] 
**ok_to_mail** | **bool** | Applicants consent for receiving mails. Valid values: true and false | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

