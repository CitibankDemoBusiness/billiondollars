# UpdateMfaRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_mfa_verified** | **bool** | Indicates whether MFA flag is verified or not. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

