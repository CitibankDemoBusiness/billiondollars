# DisplayApplicantDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**\Swagger\Client\Model\ECMName**](ECMName.md) |  | 
**address** | [**\Swagger\Client\Model\ECMAddress[]**](ECMAddress.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

