# KbaQResponseOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**option_sequence_number** | **int** | Option sequence number | [optional] 
**option_text** | **string** | Option text to be displayed to the end user. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

