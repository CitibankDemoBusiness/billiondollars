# InsertDocumentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document_details** | [**\Swagger\Client\Model\DocumentDetails**](DocumentDetails.md) |  | 
**control_flow_id** | **string** | Control flow id is used to control the flow for subsequent requests in the session. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

